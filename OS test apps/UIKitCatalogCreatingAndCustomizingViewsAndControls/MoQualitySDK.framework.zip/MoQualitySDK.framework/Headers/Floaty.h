//
//  Floaty.h
//
//  Created by LeeSunhyoup on 2016. 8. 9..
//  Copyright © 2016년 Lee Sun-Hyoup. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KCFloatingActionButton.
FOUNDATION_EXPORT double FloatyVersionNumber;

//! Project version string for KCFloatingActionButton.
FOUNDATION_EXPORT const unsigned char FloatyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Floaty/PublicHeader.h>
