//
//  UIApplication+swizzle.h
//  MoQualitySDK
//
//  Created by Anushk Mittal on 1/30/17.
//  Copyright © 2017 Anushk Mittal. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Attribute;
@interface UIApplication (swizzle)
@end
