//
//  UIButton.h
//  MoQualitySDK
//
//  Created by Anushk Mittal on 1/19/17.
//  Copyright © 2017 Anushk Mittal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (SwizzleEvents)

@end
